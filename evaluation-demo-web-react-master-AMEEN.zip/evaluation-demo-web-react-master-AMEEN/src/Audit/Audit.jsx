import React from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import { Navbar, Nav } from 'react-bootstrap';
import ReactTable from 'react-table-v6'
import '../../node_modules/react-table-v6/react-table.css'

import { userActions } from '../_actions';

class Auditpage extends React.Component {
    componentDidMount() {
        this.props.getUsers();
    }

    handleDeleteUser(id) {
        return (e) => this.props.deleteUser(id);
    }

    render() {
        const { user, users } = this.props;

        const reactTable = {
            width: '100%'
        }

        const data = []

        const items = users.items;
        if(users.items) {
            users.items.map((user, index) => {
                data.push({
                userId: user.id,
                userRole: user.role,
                userCreateDate: user.createdDate,
                userFirstName: user.firstName,
                userLastName: user.lastName,
                Delete: user.deleting ? <em>Deleting...</em>
                        : user.deleteError ? <span className="text-danger">ERROR: {user.deleteError}</span>
                            : <span> <a onClick={this.handleDeleteUser(user.id)}>Delete</a></span>
                
                })
            })
        }


          const columns = [{
            Header: 'User Id',
            accessor: 'userId' // String-based value accessors!
          }, {
            Header: 'User Role',
            accessor: 'userRole',
            Cell: props => <span className='number'>{props.value}</span> // Custom cell components!
          }, {
            Header: 'User Create Date',
            accessor: 'userCreateDate'
          }, {
            Header: 'User First Name', // Custom header components!
            accessor: 'userFirstName'
          }, {
            Header: 'User Last Name', // Custom header components!
            accessor: 'userLastName'
          }, {
            Header: 'Delete', // Custom header components!
            accessor: 'Delete'
          }]

        return (
            <div>
                <Navbar bg="dark" variant="dark">
                    <Navbar.Brand ></Navbar.Brand>
                    <Nav className="mr-auto">
                        <Nav.Link ><Link to="/">Home</Link></Nav.Link>
                        <Nav.Link href="#features">Auditor</Nav.Link>
                        <Nav.Link> <Link to="/login">Logout</Link></Nav.Link>
                    </Nav>
                </Navbar>
                <div className="col-md-12">

                    <h1>Hi {user.firstName}!</h1>
                    <p>You're logged in with React!!</p>
                    <h3>All login audit :</h3>
                    <ReactTable style={reactTable} data={data} columns={columns} />

                    {users.loading && <em>Loading users...</em>}
                    {users.error && <span className="text-danger">ERROR: {users.error}</span>}
                </div>
            </div>
        );
    }
}

function mapState(state) {
    const { users, authentication } = state;
    const { user } = authentication;
    return { user, users };
}

const actionCreators = {
    getUsers: userActions.getAll,
    deleteUser: userActions.delete
}

const connectedAuditPage = connect(mapState, actionCreators)(Auditpage);
export { connectedAuditPage as Auditpage };